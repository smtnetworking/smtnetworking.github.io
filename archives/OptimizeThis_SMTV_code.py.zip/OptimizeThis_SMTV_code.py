import numpy as np
from scipy.io.wavfile import write
import wave
import soundfile

sr = 48000

# Define the stimulus generating functions

def makeEnv(dur,sr): # function that makes percussive sound envelope (thanks, Mike!)
        #Elizondo Lopez, A. E., Schlesinger, J. J., & Schutz, M. (2024). Musical timbre with varied amplitude envelope improves efficacy in auditory alarms.
            # The Journal of the Acoustical Society of America, 155(3_Supplement), A307-A307.
    t = np.linspace(0, dur, int(sr * dur), False)
    env = np.ones(np.size(t))
    env[0:int(sr*.050)] = np.linspace(0,1, int(sr * .050))
    env[int(sr*.050):]  = (np.exp(np.linspace(1,0, np.size(env) - int(sr*.050))) - 1)/np.exp(1)
    return env

def makeSquareSig(freq,dur,sr): # function that makes a square wave tone
    t = np.linspace(0, dur, int(sr * dur), False)
    sig = np.sin(freq*2*np.pi*t)
    for i in range(3,100,2):
        sig = sig + (1/i) * np.sin(i*freq*2*np.pi*t)
    sig = sig * makeEnv(dur,sr)
    return sig

def makeSineSig(note,dur,sr):
    freq = 2**((note - 69)/12) * 440
    t = np.linspace(0, dur, int(sr * dur), False)
    sig = np.sin(freq*2*np.pi*t)
    return sig * makeEnv(dur,sr)

def makeSquareChord(notes,dur,sr): # make a chord!
    sig = (np.zeros(int(dur*sr)))
    for note in notes:
        freq = 2**((note - 69)/12) * 440
        sig = sig + makeSquareSig(freq,dur,sr)/np.size(notes)
    return sig * makeEnv(dur,sr)

def makeProg(chords): # string some chords together
    sig = np.array([])
    for chord in chords:
        sig = np.append(sig,chord)
    return sig

def chooseMelNote(curMelNote,chord): # given a chord, choose a melody note
    closestChordMemberIdx = np.abs(np.array([note - curMelNote for note in allChords[chord]["notes"]])).argmin()
    return allChords[chord]["notes"][closestChordMemberIdx]
    
    

# define some chords

CM_chord   = dict()
Cm_chord   = dict()
DM_chord   = dict()
Dm_chord   = dict()
EM_chord   = dict()
Em_chord   = dict()
FM_chord   = dict()
Fm_chord   = dict()
GM_chord   = dict()
Gm_chord   = dict()
AM_chord   = dict()
Am_chord   = dict()
Bdim_chord = dict()

CM_chord["notes"]    = [48, 55, 64]
Cm_chord["notes"]    = [48, 55, 63]
DM_chord["notes"]    = [n + 2 for n in [48, 55, 64]]
Dm_chord["notes"]    = [n + 2 for n in [48, 55, 63]]
EM_chord["notes"]    = [n + 4 for n in [48, 55, 64]]
Em_chord["notes"]    = [n + 4 for n in [48, 55, 63]]
FM_chord["notes"]    = [n + 5 for n in [48, 55, 64]]
Fm_chord["notes"]    = [n + 5 for n in [48, 55, 63]]
GM_chord["notes"]    = [n + 7 for n in [48, 55, 64]]
Gm_chord["notes"]    = [n + 7 for n in [48, 55, 63]]
AM_chord["notes"]    = [n + 9 for n in [48, 55, 64]]
Am_chord["notes"]    = [n + 9 for n in [48, 55, 63]]
Bdim_chord["notes"]  = [59, 65, 74]

# define a grammar
CM_chord["transitionProbabilities"]     = np.array([.05,.05,.1,.1,.05,.05,.1,.05,.2,.05,.05,.1,.05])
Cm_chord["transitionProbabilities"]     = np.array([.2,.05,.025,.025,.0125,.0125,.2,.15,.1,.1,.0125,.0125,.1])
DM_chord["transitionProbabilities"]     = np.array([.025,.0125,.05,.1,.15,.05,.1,.0125,.2,.05,.05,.2,.0125])
Dm_chord["transitionProbabilities"]     = np.array([.1,.025,.1,.05,.0125,.05,.15,.05,.2,.05,.01,.1,.0125])
EM_chord["transitionProbabilities"]     = np.array([.0125,.0125,.0125,.0125,.1,.1,.2,.0125,.0125,.0125,.25,.25,.0125])
Em_chord["transitionProbabilities"]     = np.array([.05,.0125,.15,.1,.025,.05,.1,.05,.1,.0125,.15,.15,.05])
FM_chord["transitionProbabilities"]     = np.array([.15,.15,.05,.05,.05,.05,.05,.1,.15,.1,.025,.025,.05])
Fm_chord["transitionProbabilities"]     = np.array([.1,.1,.1,.1,.05,.0125,.1,.1,.1,.1,.1,.025,.0125])
GM_chord["transitionProbabilities"]     = np.array([.15,.1,.1,.1,.0125,.0125,.1,.0125,.1,.1,.1,.1,.0125])
Gm_chord["transitionProbabilities"]     = np.array([.15,.1,.1,.1,.0125,.0125,.0125,.1,.1,.1,.1,.1,.0125])
AM_chord["transitionProbabilities"]     = np.array([.0125,.0125,.2,.25,.2,.2,.0125,.0125,.0125,.0125,.0125,.0125,.05])
Am_chord["transitionProbabilities"]     = np.array([.05,.05,.1,.1,.05,.05,.1,.05,.2,.05,.05,.1,.05])
Bdim_chord["transitionProbabilities"]   = np.array([.45,.45,.0125,.0125,.0125,.0125,.0125,.0125,.0125,.0125,0,0,0])

allChords = dict()
allChords["CM_chord"] = CM_chord
allChords["Cm_chord"] = Cm_chord
allChords["DM_chord"] = DM_chord
allChords["Dm_chord"] = Dm_chord
allChords["EM_chord"] = EM_chord
allChords["Em_chord"] = Em_chord
allChords["FM_chord"] = FM_chord
allChords["Fm_chord"] = Fm_chord
allChords["GM_chord"] = GM_chord
allChords["Gm_chord"] = Gm_chord
allChords["AM_chord"] = AM_chord
allChords["Am_chord"] = Am_chord
allChords["Bdim_chord"] = Bdim_chord

chordNames = ["CM_chord","Cm_chord","DM_chord","Dm_chord","EM_chord","Em_chord","FM_chord","Fm_chord","GM_chord","Gm_chord","AM_chord","Am_chord","Bdim_chord"]
chordDur = .5 #500 ms
numChordsInProg = 30

myProg = list()
myProg.append("CM_chord")
# Start on CM_chord, then generate random chords according to the probability given by the grammar.
for chordNum in range(1,numChordsInProg):
    tp = allChords[myProg[chordNum - 1]]["transitionProbabilities"]
    myProg.append(np.random.choice(chordNames,1,tp.tolist())[0])

chordList = list()
for chord in myProg:
    chordList.append(allChords[chord]["notes"])

chordProg = np.array([])
melSig = np.array([])
curMelNote = 60
for chordNum in range(len(myProg)):
    chord = myProg[chordNum]
    chordProg = np.append(chordProg,makeSquareChord(allChords[chord]["notes"],chordDur,sr))          
    if chordNum%4 == 0:
        curMelNote = chooseMelNote(curMelNote,chord) + 12
        melSig = np.append(melSig,makeSineSig(curMelNote,4*chordDur,sr))
        
soundfile.write('chordProg.wav',chordProg + melSig[0:len(chordProg)],sr)
